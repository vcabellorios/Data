#!/bin/bash

sed -i 's/(//g' arqreceiver.txt
sed -i 's/)//g' arqreceiver.txt
sed -i 's/,//g' arqreceiver.txt
