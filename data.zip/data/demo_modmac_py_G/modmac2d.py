#!/usr/bin/env python

import os
import subprocess

try:
    # This will work in Python 2.7
    import Tkinter
except ImportError:
    # This will work in Python 3.5
    import tkinter as Tkinter

#import ScrolledText

# -----------------------------------------------------------------------------
# To use matplotlib, the author must use the TkAgg backend, or none of this will
# work and a long string of inexplicable error messages will ensue.
# -----------------------------------------------------------------------------

# Define a bold font:
BOLD = ('Courier', '12', 'bold')

# Create main application window.
root = Tkinter.Tk()
root.title("Modelagem Acustica 2D-fonte pontual")

# Create a text box explaining the application.
greeting = Tkinter.Label(text="Parametros de modelagem:", font=BOLD)
greeting.pack(side='top')

# Create a frame for variable names and entry boxes for their values.
frame = Tkinter.Frame(root)
frame.pack(side='top')

# Variables for the calculation, and default values.
sdirmodelo = Tkinter.StringVar()
sdirmodelo.set('modelo')

sdirmodelagem = Tkinter.StringVar()
sdirmodelagem.set('modelagem')

sNX = Tkinter.StringVar()
sNX.set('416')

sNZ = Tkinter.StringVar()
sNZ.set('160')

sdx = Tkinter.StringVar()
sdx.set('10.')

sdt = Tkinter.StringVar()
sdt.set('0.001')

sfreq = Tkinter.StringVar()
sfreq.set('10.')

sNam = Tkinter.StringVar()
sNam.set('1000.')

sNT = Tkinter.StringVar()
sNT.set('1500.')

ssnap = Tkinter.StringVar()
ssnap.set('100.')

snbord = Tkinter.StringVar()
snbord.set('100.')

salfa = Tkinter.StringVar()
salfa.set('0.0008')

ssubdt = Tkinter.StringVar()
ssubdt.set('1')

swvlt = Tkinter.StringVar()
swvlt.set('1')

sfilemod = Tkinter.StringVar()
sfilemod.set('vp.bin')

ssx = Tkinter.StringVar()
ssx.set('0')

ssz = Tkinter.StringVar()
ssz.set('0')


ssnapview = Tkinter.StringVar()
ssnapview.set('0')


# Create text boxes and entry boxes for the variables.
# Use grid geometry manager instead of packing the entries in.

row_counter =0
aa_text = Tkinter.Label(frame, text='Diretorio do modelo:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sdirmodelo)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Diretorio de modelagem:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sdirmodelagem)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Numero de celulas na direcao x:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sNX)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Numero de celulas na direcao z:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sNZ)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Dimensao do grid (m):',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sdx)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Amostragem temporal (s):',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sdt)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Frequencia da fonte (Hz):',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sfreq)
aa_entry.grid(row=row_counter, column=1, columnspan=2)


row_counter += 1
aa_text = Tkinter.Label(frame, text='Numero de passos da simulacao:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sNT)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Intervalo entre os instantaneos:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=ssnap)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Numero de amostras da borda de atenuacao:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=snbord)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Parametro de atenuacao da borda (Cerjan):',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=salfa)
aa_entry.grid(row=row_counter, column=1, columnspan=2)


row_counter += 1
aa_text = Tkinter.Label(frame, text='Subamostragem do sismograma:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=ssubdt)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Wavelet:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=swvlt)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Arquivo de velocidade:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=sfilemod)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

# Posicao da fonte
row_counter += 1
aa_text = Tkinter.Label(frame,text='Posicao da fonte:',font=BOLD)
aa_text.grid(row=row_counter, column=0)

row_counter += 1
aa_entry = Tkinter.Entry(frame, width=30, textvariable=ssx)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

aa_text = Tkinter.Label(frame, text='Posicao X da fonte (amostras):',justify='left')
aa_text.grid(row=row_counter, column=0)

row_counter += 1
aa_entry = Tkinter.Entry(frame, width=30, textvariable=ssz)
aa_entry.grid(row=row_counter, column=1, columnspan=2)

aa_text = Tkinter.Label(frame, text='Posicao Z da fonte (amostras):',justify='left')
aa_text.grid(row=row_counter, column=0)

# ANALISE DE SNAPSHOT
row_counter += 1
aa_text = Tkinter.Label(frame,text='Analise de instantaneos:',font=BOLD)
aa_text.grid(row=row_counter, column=0)

row_counter += 1
aa_text = Tkinter.Label(frame, text='Instantaneo:',justify='left')
aa_text.grid(row=row_counter, column=0)

aa_entry = Tkinter.Entry(frame, width=30, textvariable=ssnapview)
aa_entry.grid(row=row_counter, column=1, columnspan=2)


## Funcoes de execucao ##

###############################
#### VISUALIZA VELOCIDADE  ####
###############################
def vervel(event=None):
    dx          = float(float(sdx.get()))
    NZ          = int(float(sNZ.get()))

    dirmodelo   = sdirmodelo.get()
    filemod     = sfilemod.get()

    command ="ximage n1={} <{}/{} d1={} d2={} title=velocidade &".format(NZ,dirmodelo,filemod,dx,dx)
    os.system(command)

#################
#### MODELAR ####
#################
def modelar(event=None):

    NX      = int(float(sNX.get()))
    NZ      = int(float(sNZ.get()))
    dx      = float(float(sdx.get()))
    dt      = float(float(sdt.get()))
    freq    = float(float(sfreq.get()))
    Nam     = int(float(sNam.get()))
    NT      = int(float(sNT.get()))
    snap    = int(float(ssnap.get()))
    nbord   = int(float(snbord.get()))
    alfa    = float(float(salfa.get()))
    subdt   = int(float(ssubdt.get()))
    wvlt    = int(float(swvlt.get()))
    sx      = int(float(ssx.get()))
    sz      = int(float(ssz.get()))

    NTSIS   = NT-Nam*0.5

    ## LIMITES DO MODELO
    xbeg = 0
    xend = NX
    zbeg = 0
    zend = NZ
    

    dirmodelo        = sdirmodelo.get()
    dirmodelagem     = sdirmodelagem.get()
    filemod          = sfilemod.get()

    # ESCREVENDO ARQUIVO DE PARAMETROS
    command = "echo {} {} {} {} {} {} {} {} {} {}  {}  {}  {}/{}> paracel.txt".\
    format(NX,NZ,dx,NT,Nam,freq,snap,nbord,alfa,dt,subdt,wvlt,dirmodelo,filemod)
    print(command)
    os.system(command)

    # ESCREVENDO O ARQUIVO DE FONTE
    command = "echo 1         {} {} 0 1000 0 > arqfonte.txt".\
    format (sx,sz)
    print(command)
    os.system(command)

    # ESCREVENDO O ARQUIVO DE RECEPTOR
    NX = int(float(sNX.get()))
    arq = open('arqreceiver.txt', 'w')
    print (NX)
    arq.write(str(NX))
    arq.write('\n')
    arq.close()
    for x in range (0,NX):
    	arq = open ('arqreceiver.txt', 'r')
    	cont = arq.readlines()
    	r = (x, 0, 0, 1000, 0)
    	cont.append (str(r))
    	cont.append('\n')
    	arq = open ('arqreceiver.txt', 'w')
    	arq.writelines(cont)
    	arq.close()

    return_code = subprocess.call('./editgerarecs.sh', shell=True) 

##    command ='''
##    NNX={}
##    i=0
##    int=1
##    fim=$NNX
##
##    echo $NNX  >arqreceiver.txt
##    while [ $i -le $fim ]
##    do	
##  	    echo $i  0   0   1000  0 >> arqreceiver.txt
##	    i=[i+int]
##    done
##'''.format(NX)
##    os.system(command)

    # APAGANDO SIMULACAO ANTERIOR
    command = "rm sismog.bin snap*"
    os.system(command)


    # EXECUTANDO A SIMULACAO
    command = "./bin/acel2d_p2"
    os.system(command)


    # CRIANDO LIMITES DO MODELO EM AMOSTRAS
    command = "echo {} {}   {} {}  {} {}   {} {}   {} {} > limite". format(zbeg,xbeg,zbeg,xend,zend,xend,zend,xbeg,zbeg,xbeg)
    os.system(command)


    # CRIANDO DIRETORIO DE MODELAGEM E MOVENDO ARQUIVOS 
    command = "mkdir {}". format(dirmodelagem)
    os.system(command)

    command = "mv sismog.bin {}/.". format(dirmodelagem)
    os.system(command)

    command = "mv snap* {}/.". format(dirmodelagem)
    os.system(command)
    
    command = "mv arq*.txt {}/.". format(dirmodelagem)
    os.system(command)

###############################
#### VISUALIZAR SISMOGRAMA ####
###############################
def versismog(event=None):
    dx      = float(float(sdx.get()))
    dt      = float(float(sdt.get()))
    Nam     = int(float(sNam.get()))
    NT      = int(float(sNT.get()))
    NTSIS   = int(NT-Nam/2)

    dirmodelagem     = sdirmodelagem.get()

    command ="ximage n1={} <{}/sismog.bin d1={} d2={} perc=99 &".format(NTSIS,dirmodelagem,dt,dx)
    os.system(command)

###############################
#### VISUALIZAR SNAPSHOT   ####
###############################
def versnap(event=None):
    dx            = float(float(sdx.get()))
    NZ            = int(float(sNZ.get()))
    nbord         = int(float(snbord.get()))
    snapview      = int(float(ssnapview.get()))
    NZbord        = int (NZ+nbord+nbord)
    dirmodelagem  = sdirmodelagem.get()

    command ="ximage n1={} <{}/snap{} f1=-{} f2=-{} title=snap{} curve=limite npair=5 curvecolor=black &".format(NZbord,dirmodelagem,snapview,nbord,nbord,snapview)
    os.system(command)


##################
#### SAIR  #######
##################
def destroy(event=None):
    root.quit()

row_counter += 1
col_counter = 0

# Add a buttons 

button_vervel = Tkinter.Button(frame, command=vervel, text="Visualiza modelo de velocidade")
button_vervel.grid(row=row_counter, column=col_counter, sticky='EW')
col_counter += 1

button_modelar = Tkinter.Button(frame, command=modelar, text="Modelar")
button_modelar.grid(row=row_counter, column=col_counter, sticky='EW')
col_counter += 1

button_versismog = Tkinter.Button(frame, command=versismog, text="Visualiza sismograma")
button_versismog.grid(row=row_counter, column=col_counter, sticky='EW')
col_counter += 1

button_versnap = Tkinter.Button(frame, command=versnap, text="Visualiza instantaneo")
button_versnap.grid(row=row_counter, column=col_counter, sticky='EW')
col_counter += 1

button_sair = Tkinter.Button(frame, command=destroy, text="Sair")
button_sair.grid(row=row_counter, column=col_counter, sticky='EW')
col_counter += 1

# Allow pressing <Return> to create plot.
#root.bind('<Return>', run_command)

# Allow pressing <Esc> to close the window.
root.bind('<Escape>', destroy)

# Activate the window.
root.mainloop()
